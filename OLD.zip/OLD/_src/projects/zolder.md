---
title: Zolder Renovatie
description: Korte project beschrijving
cover_image: "/img/projects/zolder/zolder-5.webp"
images:
  - title: "Zolder 1"
    url: "/img/projects/zolder/zolder-1.webp"
  - title: "Zolder 2"
    url: "/img/projects/zolder/zolder-2.webp"
  - title: "Zolder 3"
    url: "/img/projects/zolder/zolder-3.webp"
  - title: "Zolder 4"
    url: "/img/projects/zolder/zolder-4.webp"
  - title: "Zolder 5"
    url: "/img/projects/zolder/zolder-5.webp"
  - title: "Zolder 6"
    url: "/img/projects/zolder/zolder-6.webp"
  - title: "Zolder 7"
    url: "/img/projects/zolder/zolder-7.webp"
  - title: "Zolder 8"
    url: "/img/projects/zolder/zolder-8.webp"
  - title: "Zolder 9"
    url: "/img/projects/zolder/zolder-9.webp"
  - title: "Zolder 10"
    url: "/img/projects/zolder/zolder-10.webp"
tags:
  - Renovatie
---

Lorem ipsum dolor sit, amet consectetur adipisicing elit. Doloremque distinctio
qui, hic alias, ex placeat ab eum ad soluta et repellat rem aliquam! Cumque
nulla, illum minima ipsa sunt nisi.

lorem ipsum
