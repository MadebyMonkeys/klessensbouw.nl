export default {
  type: "project",
  layout: "layouts/project.vto",
  templateEngine: "vto,md",
  parentTitle: "Project",
};
