import lumeCMS from "lume/cms/mod.ts";

const cms = lumeCMS();

export default cms;
